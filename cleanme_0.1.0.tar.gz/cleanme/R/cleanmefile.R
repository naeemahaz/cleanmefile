#' Clean and explore a data file
#'
#'@param x A data file
#'@return The data file will take all the NULL and NA values. Save the original file and the clean to the c: drive. Create the data file into a dataframe.  Explore the data with a summary, describe and histograms.
#'@import
cleanme <- function(dataname){
      ogfile <- write.csv(dataname, file = "OGfile.csv", row.names=FALSE)
      cleandata <- dataname[complete.cases(dataname),]
      cd <- write.csv(cleandata, file = "cleanfile.csv", row.names=FALSE)
      itsclean <- read.csv(file = "cleanfile.csv")
      as.data.frame(itsclean)
      cleansum <- summary(itsclean)
      print(cleansum)
      cleandes <- describe(itsclean)
      print(cleandes)
      View(itsclean)
      hist(itsclean)



}
